package com.moon.farmingbd;

public class Product {
    private String name;
    private double price;
    private int quantity;
    private String unitType;

    public Product() {
        // Default constructor required for Firebase
    }

    public Product(String name, double price, int quantity, String unitType) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.unitType = unitType;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getUnitType() {
        return unitType;
    }
}
