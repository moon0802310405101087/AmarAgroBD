package com.moon.farmingbd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private Button manageProductsButton;
    private Button viewOrdersButton;
    private Button viewDeliveryButton;
    private Button logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        manageProductsButton = findViewById(R.id.manageProductsButton);
        viewOrdersButton = findViewById(R.id.viewOrdersButton);
        viewDeliveryButton = findViewById(R.id.viewDeliveryButton);
        logoutButton = findViewById(R.id.logoutButton);  // Initialize the logout button

        manageProductsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open Manage Products Activity
                Intent intent = new Intent(DashboardActivity.this, ManageProductsActivity.class);
                startActivity(intent);
            }
        });

        viewOrdersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open View Orders Activity
                Intent intent = new Intent(DashboardActivity.this, ViewOrdersActivity.class);
                startActivity(intent);
            }
        });

        viewDeliveryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open View Deliveries Activity
                Intent intent = new Intent(DashboardActivity.this, ViewDeliveriesActivity.class);
                startActivity(intent);
            }
        });


        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to MainActivity (Login screen or Home screen)
                Intent intent = new Intent(DashboardActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Optionally, finish the current activity to prevent going back to the dashboard
            }
        });
    }
}
