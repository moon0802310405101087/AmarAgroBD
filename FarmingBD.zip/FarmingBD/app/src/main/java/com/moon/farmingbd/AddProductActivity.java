package com.moon.farmingbd;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddProductActivity extends AppCompatActivity {

    private EditText productNameInput, productPriceInput, productQuantityInput;
    private Spinner priceUnitSpinner, quantityUnitSpinner;
    private Button saveProductButton;

    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    private DatabaseReference productsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        productNameInput = findViewById(R.id.productNameInput);
        productPriceInput = findViewById(R.id.productPriceInput);
        productQuantityInput = findViewById(R.id.productQuantityInput);
        priceUnitSpinner = findViewById(R.id.priceUnitSpinner);
        quantityUnitSpinner = findViewById(R.id.quantityUnitSpinner);
        saveProductButton = findViewById(R.id.saveProductButton);

        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        productsRef = database.getReference("products");

        saveProductButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveProduct();
            }
        });
    }

    private void saveProduct() {
        String productName = productNameInput.getText().toString().trim();
        String productPriceStr = productPriceInput.getText().toString().trim();
        String productQuantityStr = productQuantityInput.getText().toString().trim();
        String priceUnit = priceUnitSpinner.getSelectedItem().toString();
        String quantityUnit = quantityUnitSpinner.getSelectedItem().toString();

        if (TextUtils.isEmpty(productName) || TextUtils.isEmpty(productPriceStr) || TextUtils.isEmpty(productQuantityStr)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double price, quantity;
        try {
            price = Double.parseDouble(productPriceStr);
            quantity = Double.parseDouble(productQuantityStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid number format", Toast.LENGTH_SHORT).show();
            return;
        }

        String userId = mAuth.getCurrentUser().getUid();
        String productId = productsRef.child(userId).push().getKey();

        if (productId != null) {
            Product product = new Product(productName, price, quantity, priceUnit, quantityUnit);
            productsRef.child(userId).child(productId).setValue(product).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(this, "Product saved successfully!", Toast.LENGTH_SHORT).show();
                    productNameInput.setText("");
                    productPriceInput.setText("");
                    productQuantityInput.setText("");
                } else {
                    Toast.makeText(this, "Failed to save product", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public static class Product {
        public String name;
        public double price;
        public double quantity;
        public String priceUnit;
        public String quantityUnit;

        public Product() {
        }

        public Product(String name, double price, double quantity, String priceUnit, String quantityUnit) {
            this.name = name;
            this.price = price;
            this.quantity = quantity;
            this.priceUnit = priceUnit;
            this.quantityUnit = quantityUnit;
        }
    }
}
