package com.moon.farmingbd;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewProductsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter productAdapter;
    private List<Product> productList;

    // Firebase instances
    private FirebaseDatabase database;
    private DatabaseReference productsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_products);

        // Initialize Firebase instances
        database = FirebaseDatabase.getInstance();
        productsRef = database.getReference("products");

        // Initialize RecyclerView and Adapter
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        productList = new ArrayList<>();
        productAdapter = new ProductAdapter(productList);
        recyclerView.setAdapter(productAdapter);

        // Fetch and display all products from all owners
        fetchAllProducts();
    }

    private void fetchAllProducts() {
        // Retrieve all products from all users (owners) from Firebase
        productsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Clear the existing product list before loading new data
                productList.clear();

                // Loop through each user (owner) and their products
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot productSnapshot : userSnapshot.getChildren()) {
                        Product product = productSnapshot.getValue(Product.class);
                        if (product != null) {
                            productList.add(product);
                        }
                    }
                }

                // Notify the adapter that the data has been updated
                productAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Log detailed error message and display a user-friendly error message
                Log.e("Firebase", "Failed to load products: " + databaseError.getMessage());
                Toast.makeText(ViewProductsActivity.this, "Failed to load products: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    // Adapter for RecyclerView to display product details
    public static class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

        private List<Product> productList;

        public ProductAdapter(List<Product> productList) {
            this.productList = productList;
        }

        @Override
        public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            // Inflate the item layout for products
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
            return new ProductViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ProductViewHolder holder, int position) {
            Product product = productList.get(position);
            holder.productNameTextView.setText(product.name);
            holder.productPriceTextView.setText(String.format("Price Taka: %.2f", product.price));
        }

        @Override
        public int getItemCount() {
            return productList.size();
        }

        // ViewHolder for individual product items
        public static class ProductViewHolder extends RecyclerView.ViewHolder {

            TextView productNameTextView;
            TextView productPriceTextView;

            public ProductViewHolder(View itemView) {
                super(itemView);
                productNameTextView = itemView.findViewById(R.id.productNameTextView);
                productPriceTextView = itemView.findViewById(R.id.productPriceTextView);
            }
        }
    }

    // Product model class to store product data
    public static class Product {
        public String name;
        public double price;

        // Default constructor for Firebase
        public Product() {
            // Default constructor required for calls to DataSnapshot.getValue(Product.class)
        }

        // Constructor for Product class
        public Product(String name, double price) {
            this.name = name;
            this.price = price;
        }
    }
}
