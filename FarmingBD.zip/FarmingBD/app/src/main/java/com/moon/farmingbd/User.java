package com.moon.farmingbd;

public class User {
    private String name;
    private String email;
    private String role;

    // Empty constructor required for Firestore
    public User() {}

    public User(String name, String email, String role) {
        this.name = name;
        this.email = email;
        this.role = role;
    }

    // Getter methods (optional if needed)
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }
}
