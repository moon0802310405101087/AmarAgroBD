package com.moon.farmingbd;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class CustomerDashboardActivity extends AppCompatActivity {

    private TextView welcomeMessageTextView;
    private Button viewProductsButton, placeOrderButton, orderHistoryButton;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dashboard);

        // Ini  FAuth
        mAuth = FirebaseAuth.getInstance();

        // Ini views
        welcomeMessageTextView = findViewById(R.id.welcomeMessageTextView);
        viewProductsButton = findViewById(R.id.viewProductsButton);
        placeOrderButton = findViewById(R.id.placeOrderButton);
        orderHistoryButton = findViewById(R.id.orderHistoryButton);


        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            welcomeMessageTextView.setText("Welcome, " + userEmail);
        }


        viewProductsButton.setOnClickListener(v -> {
            // Open ViewProductsActivity
            Intent intent = new Intent(CustomerDashboardActivity.this, ViewProductsActivity.class);
            startActivity(intent);
        });

        placeOrderButton.setOnClickListener(v -> {
            // Open PlaceOrderActivity (create this later)
            Intent intent = new Intent(CustomerDashboardActivity.this, PlaceOrderActivity.class);
            startActivity(intent);
        });

        orderHistoryButton.setOnClickListener(v -> {
            // Open OrderHistoryActivity (create this later)
            Intent intent = new Intent(CustomerDashboardActivity.this, OrderHistoryActivity.class);
            startActivity(intent);
        });
    }
}
